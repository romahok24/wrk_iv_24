﻿namespace ConsoleApp2.Model.LogicBlockAttributes;

public class BooleanLogicBlockAttribute : LogicBlockAttribute
{
    public required bool Value { get; set; }
}
