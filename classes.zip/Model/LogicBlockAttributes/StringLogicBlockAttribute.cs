﻿namespace ConsoleApp2.Model.LogicBlockAttributes;

public class StringLogicBlockAttribute : LogicBlockAttribute
{
    public required string Value { get; set; }
}
