﻿namespace ConsoleApp2.Model.CharacteristicAttributes;

public class CharacteristicAttributeString : CharacteristicAttribute
{
    public required string Value { get; set; }
}
