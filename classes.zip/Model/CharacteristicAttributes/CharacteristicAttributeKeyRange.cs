﻿namespace ConsoleApp2.Model.CharacteristicAttributes;

public class CharacteristicAttributeKeyRange : CharacteristicAttribute
{
    public int From { get; set; }
    public int To { get; set; }
}
