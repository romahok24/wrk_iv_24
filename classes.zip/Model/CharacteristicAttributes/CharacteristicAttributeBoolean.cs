﻿namespace ConsoleApp2.Model.CharacteristicAttributes;

public class CharacteristicAttributeBoolean : CharacteristicAttribute
{
    public required bool Value { get; set; }
}
