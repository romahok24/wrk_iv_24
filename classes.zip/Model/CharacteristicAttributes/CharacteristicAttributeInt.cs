﻿namespace ConsoleApp2.Model.CharacteristicAttributes;

public class CharacteristicAttributeInt : CharacteristicAttribute
{
    public required int Value { get; set; }
}
