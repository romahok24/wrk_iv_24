﻿namespace ConsoleApp2.Model;

public class BaseEntity
{
    public int Id { get; set; }
}
