﻿namespace ConsoleApp2.Enums;

public enum LogicBlockAttributeTypes
{
    IsUnique = 1,
    OneFieldFilled = 2,
    ScriptFile = 3,
    DateRange = 4,
    TimeRange = 5,
    IfTrueThenEmpty = 6,
}
