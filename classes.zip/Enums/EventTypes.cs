﻿namespace ConsoleApp2.Enums;

public enum EventTypes
{
    Get,
    Create,
    Edit,
    Limit,
    Custom
}
